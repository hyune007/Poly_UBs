package com.poly.ubs.controller;

import com.poly.ubs.entity.Customer;
import com.poly.ubs.service.CustomerServiceImpl;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class ProfileController {

    @Autowired
    private CustomerServiceImpl customerService;

    @GetMapping("/profile")
    public String profile(HttpSession session, Model model) {
        Object loggedInUser = session.getAttribute("loggedInUser");

        // Kiểm tra xem người dùng đã đăng nhập và là Customer
        if (loggedInUser == null || !(loggedInUser instanceof Customer)) {
            return "redirect:/login?error=needLogin";
        }

        Customer customer = (Customer) loggedInUser;
        model.addAttribute("customer", customer);
        return "/container/user/profile";
    }

    @PostMapping("/update-profile")
    public String updateProfile(
            @RequestParam("name") String name,
            @RequestParam("phone") String phone,
            @RequestParam("email") String email,
            HttpSession session,
            RedirectAttributes redirectAttributes
    ) {
        Object loggedInUser = session.getAttribute("loggedInUser");

        // Kiểm tra xem người dùng đã đăng nhập và là Customer
        if (loggedInUser == null || !(loggedInUser instanceof Customer)) {
            return "redirect:/login?error=needLogin";
        }

        Customer customer = (Customer) loggedInUser;
        customer.setName(name);
        customer.setPhone(phone);
        customer.setEmail(email);

        customerService.save(customer);

        session.setAttribute("loggedInUser", customer);

        redirectAttributes.addFlashAttribute("success", "Cập nhật thông tin thành công!");
        return "redirect:/profile";
    }

    @PostMapping("/change-password")
    public String updatePassword(
            @RequestParam("currentPass") String currentPass,
            @RequestParam("newPass") String newPass,
            @RequestParam("confirmPass") String confirmPass,
            HttpSession session,
            RedirectAttributes redirectAttributes
    ) {
        // Lấy user từ session
        Object loggedInUser = session.getAttribute("loggedInUser");

        // Kiểm tra xem người dùng đã đăng nhập và là Customer
        if (loggedInUser == null || !(loggedInUser instanceof Customer)) {
            return "redirect:/login?error=needLogin";
        }

        Customer customer = (Customer) loggedInUser;

        if (!customer.getPassword().equals(currentPass)) {
            redirectAttributes.addFlashAttribute("error", "Mật khẩu hiện tại không đúng!");
            return "redirect:/profile";
        }


        if (!newPass.equals(confirmPass)) {
            redirectAttributes.addFlashAttribute("error", "Mật khẩu mới và xác nhận không khớp!");
            return "redirect:/profile";
        }

        customer.setPassword(newPass);

        customerService.save(customer);

        session.setAttribute("loggedInUser", customer);

        redirectAttributes.addFlashAttribute("success", "Cập nhật mật khẩu thành công!");
        return "redirect:/profile";
    }

}