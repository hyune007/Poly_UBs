package com.poly.ubs.controller;

/**
 * Bộ điều khiển quản lý địa chỉ
 */
public class AddressController {
}
