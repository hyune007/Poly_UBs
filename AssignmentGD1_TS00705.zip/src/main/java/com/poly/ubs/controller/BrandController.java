package com.poly.ubs.controller;

import com.poly.ubs.entity.Brand;
import com.poly.ubs.service.BrandServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/admin")
public class BrandController {

    @Autowired
    private BrandServiceImpl brandService;

    @GetMapping("/brand")
    public String listBrands(Model model) {
        model.addAttribute("brands", brandService.findAll());
        model.addAttribute("brand", new Brand());
        return "admin/product/brand";
    }

    @PostMapping("/save")
    public String save(@ModelAttribute("brand") Brand brand) {
        brandService.save(brand);
        return "redirect:/brand";
    }

    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") String id, Model model) {
        model.addAttribute("brand", brandService.findById(id));
        model.addAttribute("brands", brandService.findAll());
        return "admin/product/brand";
    }

    @GetMapping("/delete/{id}")
    public String delete(@PathVariable("id") String id) {
        brandService.deleteById(id);
        return "redirect:/brand";
    }
}
