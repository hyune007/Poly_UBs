package com.poly.ubs.controller;

import org.springframework.stereotype.Controller;

/**
 * Bộ điều khiển quản trị
 */
@Controller
public class AdminController {

}
